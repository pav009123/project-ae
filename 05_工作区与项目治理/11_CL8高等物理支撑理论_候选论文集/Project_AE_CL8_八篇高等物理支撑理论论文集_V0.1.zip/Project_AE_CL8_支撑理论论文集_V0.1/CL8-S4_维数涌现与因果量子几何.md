> **Project AE / 埃纳｜CL8 支撑理论专题**
>
> **状态：待审核候选，不自动覆盖现行 Canon。**
>
> **统一硬边界：**
> 1. 现实理论只作为数学结构与科学方法论启发；文中的界序工程、改界迁航、深域应用均为 Project AE 虚构推演。
> 2. 任何候选理论必须服从“对应原理”：在普通稳定、低能、局域极限恢复 GR、QFT、Maxwell 与 Newton。
> 3. 普通四维时空内始终保持局域 \(v_{m local}\le c\)；任何有效 FTL 都必须来自更底层局域性/邻接结构的工程化。
> 4. 不把第五维、超空间或其他高维通道偷偷引回界序理论。

# CL8-S4｜维数涌现与因果量子几何
## Spin Network、CDT 与“为什么普通宇宙是 3+1 维”

### 摘要
如果界序底层不是连续流形，就必须解释：

> **为什么宏观世界偏偏涌现为三维空间 + 一维时间？**

本文借鉴 spin-network 型离散量子几何与 Causal Dynamical Triangulations（CDT），提出：

> **3+1 维不是界序理论的最底层输入，而是普通低能界序相的动力学输出。**

这条路线进一步强化：改界不是利用第五维，而是在保持宏观 \(3+1\) 维相稳定的同时改变底层局域关系。

### 1. Spin network 的启发
Spin network 表明，在某些量子引力方案中，面积与体积可由离散网络量子数描述。

AE 候选网络：
\[
\Gamma_\Xi=(V,E,j,\iota,U)
\]
其中：
- \(j_e\)：关系表示标签；
- \(\iota_v\)：节点交织结构；
- \(U_{ij}\)：界序规范联络。

宏观几何来自粗粒化，而不是先有连续空间。

### 2. CDT 的启发
CDT 的重要思想是：
> 对满足因果规则的离散几何做非微扰求和，可在某参数区域得到宏观四维几何行为。

AE 借鉴：
\[
\boxed{d_{\rm macro}=4}
\]
是相图中的稳定区，而不是底层网络自带四个坐标轴。

### 3. 界序相图
定义：
\[
\mathcal P(d_s,d_H,d_w,\sigma)
\]
其中：
- \(d_s\)：谱维数；
- \(d_H\)：Hausdorff 型维数；
- \(d_w\)：walk dimension；
- \(\sigma\)：因果 signature 结构。

普通相：
\[
\mathcal P_{\rm ordinary}
\approx
\mathcal P(4,4,2,-+++).
\]

### 4. 多种“维数”不能混用
坐标维数、谱维数、Hausdorff 维数可能不同。

谱维数通过扩散回返概率：
\[
P(\tau)\sim\tau^{-d_s/2}
\]
定义：
\[
\boxed{
d_s
=
-2
\frac{d\ln P}{d\ln\tau}
}
\]

Hausdorff 型：
\[
V(R)\sim R^{d_H}.
\]

walk dimension：
\[
\langle r^2\rangle
\sim
\tau^{2/d_w}.
\]

### 5. 为什么不是五维
即使短尺度出现：
\[
d_s(\ell)\neq4,
\]
也不意味着存在一条可航行的第五维坐标 \(y\)。

有效维数流描述的是：
> 探针看到的传播自由度和网络扩散性质随尺度变化。

所以：
\[
\boxed{
d_s\neq4
\not\Rightarrow
\text{五维超空间}
}
\]

### 6. 承载域维数安全
改界过程中，界舟内部必须保持：
\[
|d_s^C-4|<\epsilon_d
\]
且低能 signature 不发生破坏性变化。

边界薄层可短暂进入临界相，但内部物质不能跟着进入非几何区。

### 7. 维数相变
假设控制参数：
\[
\lambda_\Xi
\]
改变时存在相边界：
\[
\mathcal P_4
\leftrightarrow
\mathcal P_{\rm crit}.
\]

CL8 设备不是进入 \(\mathcal P_5\) 旅行，而是在：
\[
\partial C
\]
附近接近 \(\mathcal P_{\rm crit}\)，获得重接自由度后回到普通 4D 相。

### 8. 为什么 4D 稳定
候选自由能：
\[
\mathcal F_\Xi(d_s,\sigma)
=
E_\Xi-T_\Xi S_\Xi.
\]
普通宇宙在：
\[
d_s\approx4
\]
附近存在宏观稳定区。

其原因可能与：
- 因果稳定；
- 规范传播；
- 物质复杂性；
- 熵/局域折中

有关，但本文不把“适合生命”当作物理证明。

### 9. 深域的作用
深域使：
\[
\ell_{\rm eff}
\]
逼近底层界序相关尺度，因此可以测量：
\[
d_s(\ell)
\]
从 4 偏离的迹象。

这成为“几何并非最底层”的独立证据。

### 10. 维数故障
如果改界边界失控：
- 局部 \(d_s\) 跌落过快；
- signature 失稳；
- 连接度塌缩；

可能出现：
- 场传播冻结；
- 热传输异常；
- 主体边界结构失稳。

### 11. 对应原理
宏观极限必须：
\[
d_s,d_H\rightarrow4,
\qquad
d_w\rightarrow2,
\]
并恢复 Lorentzian 四维有效时空。

### 12. 对 CL8 的支撑
回答：
\[
\boxed{\text{为什么界序底层不是连续时空，却仍能稳定地产生 3+1 维世界？}}
\]

### 13. Canon 建议
**强候选：**
- 3+1 维是稳定低能界序相；
- 深域可探测尺度相关有效维数；
- 改界内部保持 3+1 维相，不能偷渡高维旅行。

**暂不冻结：**
- 具体 spin-network 表示；
- 4D 稳定性的完整微观推导。

### 现实思想锚点
- Rovelli, Smolin, *Spin Networks and Quantum Gravity*, arXiv:gr-qc/9505006.
- Rovelli, Smolin, *Discreteness of area and volume in quantum gravity*, arXiv:gr-qc/9411005.
- Ambjørn, Jurkiewicz, Loll, *Emergence of a 4D World from Causal Quantum Gravity*, arXiv:hep-th/0404156.
- Ambjørn, Jurkiewicz, Loll, *Spectral Dimension of the Universe*, arXiv:hep-th/0505113.

**现实边界：**这些研究不证明 AE 的界序网络，也不提供 FTL。
