> **Project AE / 埃纳｜CL8 支撑理论专题**
>
> **状态：待审核候选，不自动覆盖现行 Canon。**
>
> **统一硬边界：**
> 1. 现实理论只作为数学结构与科学方法论启发；文中的界序工程、改界迁航、深域应用均为 Project AE 虚构推演。
> 2. 任何候选理论必须服从“对应原理”：在普通稳定、低能、局域极限恢复 GR、QFT、Maxwell 与 Newton。
> 3. 普通四维时空内始终保持局域 \(v_{m local}\le c\)；任何有效 FTL 都必须来自更底层局域性/邻接结构的工程化。
> 4. 不把现实量子引力猜想直接宣称为 AE 终极真理。

# CL8-S7｜尺度维数流与深域显微镜
## Asymptotic Safety、谱维数流与“为什么深域能看见平直空间看不见的界序自由度”

### 摘要
多种量子引力研究出现过一个共同主题：

> **时空的有效维数、传播性质和耦合常数可能随探测尺度变化。**

CDT 与 asymptotic-safety 相关研究都讨论过 spectral dimension 在宏观和微观尺度间流动。

AE 不直接采用这些理论，而借鉴：

> **界序自由度可能不是高能时“突然出现”，而是其有效耦合、传播维数和缺陷作用量随尺度发生重整化流；普通世界位于红外稳定区，深域工程把实验推向另一个尺度窗口。**

### 1. 谱维数
扩散回返概率：
\[
P(\sigma)
\]
定义：
\[
\boxed{
d_s(\sigma)
=
-2
\frac{d\ln P(\sigma)}
{d\ln\sigma}
}
\]
宏观普通世界：
\[
d_s\approx4.
\]
某些量子引力模型在微观尺度得到向更低谱维数流动的结果。

### 2. 界序 RG
定义能标：
\[
k\sim1/\ell.
\]
界序有效参数：
\[
g_\Xi(k),
\quad
\lambda_\Xi(k),
\quad
m_\Xi(k),
\quad
Z_\Xi(k),
\quad
\chi_\Xi(k).
\]
满足：
\[
\boxed{
k\frac{dg_i}{dk}
=
\beta_i(\{g\})
}
\]

### 3. 红外对应原理
普通尺度：
\[
k\rightarrow0.
\]
要求：
\[
\mathcal F^\Xi\rightarrow0
\]
到实验不可见范围，且：
\[
g_{\mu\nu}
\]
满足 GR 有效动力学。

因此：
\[
\boxed{
\lim_{k\rightarrow0}
\mathcal L_{\rm full}(k)
=
\mathcal L_{\rm GR+QFT}
}
\]

### 4. 深域不是“能量越大越好”
黑洞背景引入：
\[
\ell_{\rm curv},
\]
人工场引入：
\[
\ell_{\rm drive},
\]
相干系统引入：
\[
\ell_{\rm coh}.
\]
有效探测尺度：
\[
\boxed{
\ell_{\rm eff}
=
F(
\ell_{\rm curv},
\ell_{\rm drive},
\ell_{\rm coh}
)
}
\]
所以深域作用是“改变可访问的有效 RG 尺度”，而不是单纯提供巨量能量。

### 5. CL8 工作窗口
假设存在：
\[
k_1<k<k_2.
\]
在此：
- 界序缺陷可成核；
- 手征相可控制；
- 普通物质仍能安全存在；
- 改界作用量有限。

若：
\[
k<k_1,
\]
界序自由度被冻结。

若：
\[
k>k_2,
\]
进入主体不安全的非几何区。

所以：
\[
\boxed{
\text{CL8不是“越高能越好”，而是找到正确尺度窗口}
}
\]

### 6. 多深域 = RG 扫描仪
银心、大麦哲伦、M32、M31 提供不同背景：
\[
(M,a_*,\mathcal K,\mathcal M_{\rm env}).
\]
每个深域测：
\[
g_\Xi^{(i)}(k_{\rm eff}),
\quad
d_s^{(i)}(k_{\rm eff}).
\]
若不同深域经校正后落在同一：
\[
\beta_\Xi(g)
\]
流线上，证明它们看到的是同一基础自由度。

### 7. 为什么“大黑洞”不等于“更接近 CL8”
事件视界附近某些曲率标量并不随黑洞质量简单增加。

因此不能写：
\[
M_{\rm BH}\uparrow
\Rightarrow
\text{界序更容易}.
\]

真正决定工作区的是：
- 自旋；
- 曲率不变量；
- 核区环境；
- 驱动频谱；
- 界序 RG 参数。

### 8. 尺度依赖的缺陷张力
候选：
\[
\sigma_\Xi(k)
=
Z_\Xi(k)
\sigma_{\Xi,0}.
\]
在普通尺度：
\[
\sigma_\Xi\gg1
\]
改界不可行。

在工作窗：
\[
\sigma_\Xi(k_*)\downarrow
\]
缺陷可工程化。

### 9. 尺度维数与 S4 的关系
S4 研究：
> 为什么宏观是 3+1 维。

S7 研究：
> 同一个宇宙在不同探测尺度下有效维数和传播自由度是否变化。

二者兼容：
\[
d_s(\ell\rightarrow\infty)\rightarrow4
\]
但：
\[
d_s(\ell\rightarrow\ell_\Xi)
\]
可偏离4。

这仍不意味着有一个第五维航路。

### 10. 人工深域
成熟 CL8 可能通过多尺度构态驱动：
\[
H_\Xi^{\rm multi-scale}
\]
在较小区域复现：
\[
k_{\rm eff}\approx k_*.
\]
但这不自动复现完整深域育生环境，因此与“深域再生产约束”不冲突。

### 11. RG 临界事故
设备若越过：
\[
k_2
\]
可能发生：
- 界序耦合失控；
- 有效维数骤变；
- 低能物质描述失效；
- 手征边界塌缩。

这形成 CL8 极高危“越窗”事故。

### 12. 对 CL8 的支撑
回答：
\[
\boxed{\text{为什么普通世界看不到界序，而深域能够逐步显影？}}
\]

### 13. Canon 建议
**强候选：**
- 界序有效参数具有尺度依赖；
- 深域可作为时空/界序的 RG 显微镜；
- CL8 存在有限工作窗口。

**暂不冻结：**
- asymptotic safety 是否就是 AE 终极 UV 完备；
- 微观谱维数是否必然趋近2；
- 具体 beta functions。

### 现实思想锚点
- Reuter, Saueressig, *Fractal space-times under the microscope*, arXiv:1110.5224.
- Ambjørn, Jurkiewicz, Loll, *Spectral Dimension of the Universe*, arXiv:hep-th/0505113.
- Lauscher, Reuter, *Fractal Spacetime Structure in Asymptotically Safe Gravity*, arXiv:hep-th/0508202.

**现实边界：**这些工作不证明 AE 的界序工作窗或 FTL。
