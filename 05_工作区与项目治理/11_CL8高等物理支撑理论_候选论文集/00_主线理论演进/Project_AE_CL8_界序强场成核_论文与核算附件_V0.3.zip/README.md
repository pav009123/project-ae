# Project AE｜CL8界序成核论文专题包 V0.3

**这是论文专题包，不是 Project AE 完整项目总包。** 原 V1.4.14 总包未改动，已有批准设定未被本包自动覆盖。

## 核心文件

`Project_AE_CL8_界序动力学II_强场成核与受控改界_论文V0.3.md`

本稿整合此前 V0.2 的界序、改界与对应原理，新增施温格启发的受驱缺陷成核模型，明确区分局部成核、非局域响应、寻址、承载和主体连续性。共40组编号公式；部分为现实理论公式，部分为明确标记的 AE 假说或条件性推导，不能一概当作现实规律。

## 阅读顺序

先读主文第0、1、4、7、10、12、19、21节，可掌握世界观与关键边界。数学细节集中于第3、5、6、8、11、13、15、18节。所有新增机制仍待用户审核。

## 附件

- `supplement/verify_models.py`：实际运行的简化模型复核代码，包含22项检查。
- `supplement/verification_results.json`：完整数值和运行环境版本。
- `supplement/nucleation_scan.csv`：任意模型单位下的成核指数示例。
- `supplement/tilted_barrier.csv`：倾斜周期势的势垒示例。
- `supplement/exposure_example.csv`：有限暴露量与期望计数示例。
- `supplement/版本差异与审查记录.md`：旧稿修正点和检查边界。
- `supplement/provenance.json`：项目输入文件、总控条目的来源及哈希。
- `prior_versions/`：旧论文 V0.2、DP-01和83号总控的原始副本，未改写。
- `MANIFEST_SHA256.json`：除清单自身以外，全部包内文件的校验值。

## 复核代码

环境需要 Python 3.10+、NumPy、SciPy、SymPy、NetworkX。具体本次版本已记录在 JSON 中。

```bash
python supplement/verify_models.py --out supplement
```

输出验证的是选定数学模型与反例，不包含真实界序实验、真实 FTL 仿真、完整量子引力或宏观界舟运输解。没有制作视觉资产。

## 归档原则

本包可作为既有“科学论文组／CL8界序”工作区的新候选材料。用户批准前，不用本稿未知参数或未解机理反向修改索恩亚光速远岸历史、虫洞双端部署、深域再生产约束或主体伦理。
