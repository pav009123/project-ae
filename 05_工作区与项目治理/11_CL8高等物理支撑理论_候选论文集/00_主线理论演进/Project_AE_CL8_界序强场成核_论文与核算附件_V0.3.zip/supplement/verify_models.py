#!/usr/bin/env python3
"""Reproduce mathematical toy-model checks for Project AE CL8 paper V0.3.

These checks do NOT simulate real spacetime manipulation or establish FTL.
Only the Schwinger field conversion uses SI constants. Other computations use
explicit arbitrary dimensionless model units, not inferred AE engine parameters.

Usage: python verify_models.py --out OUTPUT_DIRECTORY
Dependencies: Python 3.10+, numpy, scipy, sympy, networkx.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
import platform
from pathlib import Path
import numpy as np
import scipy
from scipy import constants as const
from scipy.integrate import simpson
import sympy as sp
import networkx as nx


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise ValueError("Cannot write empty table")
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def smoothstep(x: np.ndarray) -> np.ndarray:
    x = np.clip(x, 0.0, 1.0)
    return x*x*(3.0-2.0*x)


def main(out: Path) -> None:
    out.mkdir(parents=True, exist_ok=True)
    checks: dict[str, bool] = {}
    results: dict = {
        "scope": "Conditional mathematical checks; not real FTL, not real measurements",
        "runtime": {"python": platform.python_version(), "numpy": np.__version__,
                    "scipy": scipy.__version__, "sympy": sp.__version__, "networkx": nx.__version__},
    }
    # 1. Real physical conversion; no experimental observation is claimed.
    critical = const.m_e**2 * const.c**3 / (const.e*const.hbar)
    threshold = 2*const.m_e*const.c**2 / (const.e*1e6)
    results["qed_SI"] = {"Schwinger_E_V_per_m": critical, "pair_rest_energy_MeV": threshold}
    checks["qed_scale"] = bool(1.32e18 < critical < 1.33e18 and 1.021 < threshold < 1.023)

    # 2. Sine-Gordon kink: K=rho=U=hbar=1 in arbitrary units.
    x = np.linspace(-24.0, 24.0, 24001)
    theta = 4*np.arctan(np.exp(x))
    derivative = 2/np.cosh(x)
    second_derivative = -2*np.sinh(x)/(np.cosh(x)**2)
    energy = float(simpson(.5*derivative**2+1-np.cos(theta), x=x))
    charge = float((theta[-1]-theta[0])/(2*np.pi))
    residual = float(np.max(np.abs(second_derivative-np.sin(theta))))
    results["kink"] = {"energy_integral": energy, "analytic_energy": 8.0,
                       "charge": charge, "max_equation_residual": residual}
    checks["kink_energy"] = abs(energy-8)<1e-9
    checks["kink_charge"] = abs(charge-1)<1e-9
    checks["kink_equation"] = residual<1e-12
    # Kink/antikink trial profile: not an exact finite-separation static solution.
    sep = 16.0
    xp = np.linspace(-40, 40, 40001)
    pair = 4*np.arctan(np.exp(xp+sep/2))-4*np.arctan(np.exp(xp-sep/2))
    pair_der = 2/np.cosh(xp+sep/2)-2/np.cosh(xp-sep/2)
    pair_energy = float(simpson(.5*pair_der**2+1-np.cos(pair), x=xp))
    pair_charge = float((pair[-1]-pair[0])/(2*np.pi))
    results["kink_pair_trial"] = {"separation": sep, "energy": pair_energy,
                                  "net_charge": pair_charge, "is_exact_static_solution": False}
    checks["pair_net_charge"] = abs(pair_charge)<1e-9
    checks["pair_large_separation_energy"] = abs(pair_energy-16)<1e-3

    # 3. Tilted periodic potential barrier; f/U<1 required for metastable wells.
    barriers=[]
    for j in [0.0, 0.1, 0.3, 0.6, 0.9, 0.99, 1.0]:
        height = 2*(math.sqrt(max(0.,1-j*j))-j*math.acos(j))
        barriers.append({"f_over_U": j, "barrier_over_U": height})
    write_csv(out/"tilted_barrier.csv", barriers)
    checks["barrier_monotone"] = all(a["barrier_over_U"]>b["barrier_over_U"] for a,b in zip(barriers,barriers[1:]))
    checks["barrier_vanishes_at_one"] = barriers[-1]["barrier_over_U"] == 0

    # 4. Thin-wall 1+1-dimensional bounce exponent: B=pi*epsilon^2/(hbar*c_Xi*Delta_f).
    # No black-hole to U map is fitted; U is an independent illustrative parameter.
    rows=[]
    U_values=[1.0, .81, .64, .49]
    K=rho=hbar=1.0
    delta_f=.2
    c_xi=math.sqrt(K/rho)
    baseline=None
    for U in U_values:
        width=math.sqrt(K/U)
        epsilon=8*math.sqrt(K*U)
        radius=epsilon/delta_f
        B=math.pi*epsilon**2/(hbar*c_xi*delta_f)
        if baseline is None: baseline=B
        rows.append({"U":U, "defect_energy":epsilon, "width":width,
                     "critical_radius":radius, "radius_over_width":radius/width,
                     "B":B, "log10_rate_over_prefactor":-B/math.log(10),
                     "log10_enhancement_vs_U1":(baseline-B)/math.log(10)})
    write_csv(out/"nucleation_scan.csv", rows)
    results["nucleation_scan"]=rows
    checks["thin_wall_radius"] = min(r["radius_over_width"] for r in rows)>15
    checks["bias_below_spinodal"] = all(delta_f/(2*math.pi)<u for u in U_values)
    R,eps,df,c,h = sp.symbols('R eps df c h', positive=True)
    S=(2*sp.pi*R*eps-sp.pi*R**2*df)/c
    checks["bounce_stationarity"] = sp.simplify(sp.diff(S,R).subs(R,eps/df))==0
    checks["bounce_action"] = sp.simplify(S.subs(R,eps/df)-sp.pi*eps**2/(c*df))==0
    checks["bounce_negative_mode"] = sp.simplify(sp.diff(S,R,2)+2*sp.pi*df/c)==0
    exposure=[]
    for B in [120., 80., 60., 48.]:
        n=1e24*math.exp(-B)
        exposure.append({"trial_exposure":1e24, "B":B, "expected_events":n,
                         "prob_at_least_one":-math.expm1(-n)})
    write_csv(out/"exposure_example.csv", exposure)
    results["exposure_example"]=exposure

    # 5. Positive spatial Laplacian alone has no Lorentzian time direction.
    cargo=nx.cycle_graph(16)
    L=nx.laplacian_matrix(cargo).toarray().astype(float)
    eigen=np.linalg.eigvalsh(L)
    checks["spatial_laplacian_positive"] = float(eigen.min())>-1e-12
    results["cargo_graph"]={"nodes":16,"lambda2":float(eigen[1]),
                            "is_consciousness_test":False}
    lam=np.linspace(0.,1.,1001)
    bA=1-smoothstep(lam/.4)
    bB=smoothstep((lam-.6)/.4)
    max_product=float(np.max(bA*bB))
    off_fraction=float(np.mean((bA<1e-12)&(bB<1e-12)))
    results["boundary_schedule"]={"maximum_bA_times_bB":max_product,
                                    "external_disconnection_parameter_interval":[.4,.6],
                                    "sampled_off_fraction":off_fraction,
                                    "internal_graph_unchanged":True}
    checks["boundary_no_overlap"] = max_product<1e-14
    checks["boundary_endpoints"] = bA[0]==1 and bB[0]==0 and bA[-1]==0 and bB[-1]==1
    # Endpoint two-edge switch conserves every port's degree; transient states need support.
    G0=nx.Graph();G0.add_nodes_from(['c','a','d','b']);G0.add_edges_from([('c','a'),('d','b')])
    G1=nx.Graph();G1.add_nodes_from(G0);G1.add_edges_from([('c','b'),('d','a')])
    checks["switch_endpoint_degrees"] = dict(G0.degree())==dict(G1.degree())

    # 6. Explicit cospectral non-isomorphic example: spectrum alone is not a unique address.
    seen={};found=None
    for graph in nx.graph_atlas_g():
        if graph.number_of_nodes()<4 or not nx.is_connected(graph):continue
        mat=nx.laplacian_matrix(graph).toarray().astype(int)
        key=tuple(np.round(np.linalg.eigvalsh(mat.astype(float)),8))
        if key in seen:
            other=seen[key]
            if not nx.is_isomorphic(graph,other):
                p1=sp.Matrix(mat.tolist()).charpoly().as_expr()
                mat2=nx.laplacian_matrix(other).toarray().astype(int)
                p2=sp.Matrix(mat2.tolist()).charpoly().as_expr()
                if sp.expand(p1-p2)==0:
                    found={"nodes":graph.number_of_nodes(),"edges_A":sorted(map(list,graph.edges())),
                           "edges_B":sorted(map(list,other.edges())),
                           "laplacian_characteristic_polynomial":str(sp.expand(p1)),
                           "non_isomorphic":True}
                    break
        seen[key]=graph
    checks["nonunique_spectrum_counterexample"] = found is not None
    results["cospectral_counterexample"]=found
    # Equal feature likelihoods and equal priors cannot imply a unique high-confidence lock.
    likelihood=np.exp(-.5*np.array([0.,0.]))
    post=likelihood/likelihood.sum()
    results["ambiguous_address_posterior"]=post.tolist()
    checks["posterior_not_raw_likelihood"] = np.allclose(post,[.5,.5])

    # 7. DAG is a necessary finite history check, not a physical chronology-protection proof.
    dag=nx.DiGraph([(0,1),(1,2),(2,3)])
    checks["forward_causal_history"] = nx.is_directed_acyclic_graph(dag)
    dag.add_edge(3,0)
    checks["causal_loop_detected"] = not nx.is_directed_acyclic_graph(dag)

    # 8. Ordinary local unitaries on an entangled pair do not signal to the other half.
    bell=np.array([1.,0.,0.,1.])/math.sqrt(2)
    density=np.outer(bell,bell)
    pauli_x=np.array([[0.,1.],[1.,0.]])
    op=np.kron(pauli_x,np.eye(2))
    changed=op@density@op.T
    rhoB=np.trace(density.reshape(2,2,2,2),axis1=0,axis2=2)
    rhoB2=np.trace(changed.reshape(2,2,2,2),axis1=0,axis2=2)
    results["no_signal_example"]={"difference_norm":float(np.linalg.norm(rhoB-rhoB2))}
    checks["entanglement_no_signal_example"] = np.allclose(rhoB,rhoB2)

    # 9. Schwarzschild curvature at a fixed r/r_s scales as M^-4.
    results["black_hole_mass_ratio_check"]={"mass_ratio":10.,"horizon_K_ratio":1e-4}
    results["checks"]={k:bool(v) for k,v in checks.items()}
    results["passed"]=sum(bool(v) for v in checks.values())
    results["total"]=len(checks)
    (out/"verification_results.json").write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding="utf-8")
    if not all(checks.values()):
        raise RuntimeError("Failed checks: "+", ".join(k for k,v in checks.items() if not v))
    print(json.dumps({"passed":results["passed"],"total":results["total"],
                      "qed_SI":results["qed_SI"],"kink":results["kink"],
                      "nucleation_scan":rows,"cospectral_counterexample":found},ensure_ascii=False,indent=2))


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out",type=Path,default=Path(__file__).resolve().parent)
    args=parser.parse_args()
    main(args.out)
